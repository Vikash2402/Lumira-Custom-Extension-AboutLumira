sap.viz.extapi.env.Language
	.register({
		id: 'en',
		value: {
			IDS_VERSION_PUBLIC: 'Public Version'
		}
	});