sap.viz.extapi.env.Language
	.register({
		id: 'es',
		value: {
			IDS_VERSION_PUBLIC: 'Versión Pública'
		}
	});