sap.viz.extapi.env.Language
	.register({
		id: 'pl',
		value: {
			IDS_VERSION_PUBLIC: 'Public Version'
		}
	});