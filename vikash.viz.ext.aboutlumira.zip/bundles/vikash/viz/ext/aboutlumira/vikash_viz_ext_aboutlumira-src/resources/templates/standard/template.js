var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"vikash.viz.ext.aboutlumira": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);